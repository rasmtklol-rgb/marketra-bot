
# Marketra Bot - FINAL

بوت اقتصاد مدفوع بنظام اشتراك لكل سيرفر مع داشبورد متقدمة.

## التشغيل السريع
docker compose up -d

أو بدون Docker:
pip install -r requirements.txt
python bot.py
python dashboard/app.py
